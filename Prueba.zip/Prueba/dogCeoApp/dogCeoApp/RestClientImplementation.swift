//
//  RestClientImplementation.swift
//  dogCeoApp
//
//  Created by capacitacion3 on 09-03-18.
//  Copyright © 2018 capacitacion3. All rights reserved.
//

import Foundation

class RestClientImplementation: RestClient {
    
    let breedUrl = "https://dog.ceo/api/breeds/list"
    let breedImageUrl = "https://dog.ceo/api/breed/%@/images"
    let decoder = JSONDecoder()
    
    
    func getBreeds(completionHandler: @escaping ([BreedEntity]?) -> Void) {
        guard let url = URL(string: breedUrl) else {
            print("error creating url")
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) {(data, response, error) in
            if let data = data {
                do {
                    let breeds = try self.decoder.decode(BreedsEntity.self, from: data)
                    completionHandler(breeds.message)
                } catch {
                    print(error)
                }
            } else {
                print("Error retrieving data")
            }
        }
        task.resume()
    }
    

    func getBreedImages(breedName: String, completionHandler: @escaping ([BreedEntity]?) -> Void) {
        guard let url = URL(string: String(format: breedImageUrl, breedName)) else {
            print("error creating url")
            return
        }
        let task = URLSession.shared.dataTask(with: url) {(data, response, error) in
            if let data = data {
                do {
                    let breeds = try self.decoder.decode(BreedsEntity.self, from: data)
                    completionHandler(breeds.message)
                } catch {
                    print(error)
                }
            } else {
                print("Error retrieving data")
            }
        }
        task.resume()
    }

}
