//
//  RestClient.swift
//  dogCeoApp
//
//  Created by capacitacion3 on 09-03-18.
//  Copyright © 2018 capacitacion3. All rights reserved.
//

import Foundation

protocol RestClient {
    func getBreeds(completionHandler: @escaping ([BreedEntity]?) -> Void)
    func getBreedImages(breedName: String, completionHandler: @escaping ([BreedEntity]?) -> Void)
}
