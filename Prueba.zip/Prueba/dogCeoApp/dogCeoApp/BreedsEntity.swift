//
//  BreedsEntity.swift
//  dogCeoApp
//
//  Created by capacitacion3 on 09-03-18.
//  Copyright © 2018 capacitacion3. All rights reserved.
//

import Foundation

struct BreedsEntity: Codable {
    let status: String
    let message: [BreedEntity]? 
}
