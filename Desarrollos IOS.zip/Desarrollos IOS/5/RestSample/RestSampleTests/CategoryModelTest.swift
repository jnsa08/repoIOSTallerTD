//
//  CategoryTest.swift
//  RestSampleTests
//
//  Created by Felipe Ruz on 08-03-18.
//  Copyright © 2018 Felipe Ruz. All rights reserved.
//

import XCTest
@testable import RestSample

class CategoryModelTest: XCTestCase {

    var sut: CategoryModel!

    override func setUp() {
        super.setUp()
    }
    
    override func tearDown() {
        sut = nil
        super.tearDown()
    }
    
    func testCanInitializeCategory() {
        sut = CategoryModel(name: "categoryTest")
        XCTAssertNotNil(sut)
        XCTAssertEqual(sut.name, "categoryTest")
    }
}
