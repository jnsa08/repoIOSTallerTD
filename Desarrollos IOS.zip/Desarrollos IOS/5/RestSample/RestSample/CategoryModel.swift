//
//  Category.swift
//  RestSample
//
//  Created by Felipe Ruz on 07-03-18.
//  Copyright © 2018 Felipe Ruz. All rights reserved.
//

import Foundation

struct CategoryModel: Codable {
    let name: String


    /// Customizacion del inicializador para poder serializar un elemento sin llave
    ///
    /// - Parameter decoder: Data en JSON request
    /// - Throws: throws una exception
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        self.name = try container.decode(String.self)
    }

    /// Inicializador con parametros
    ///
    /// - Parameter name: string nombre
    init(name: String) {
        self.name = name
    }
}
