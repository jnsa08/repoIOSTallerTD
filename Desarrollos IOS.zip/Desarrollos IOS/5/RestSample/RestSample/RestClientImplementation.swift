//
//  RestClientImplementation.swift
//  RestSample
//
//  Created by Felipe Ruz on 07-03-18.
//  Copyright © 2018 Felipe Ruz. All rights reserved.
//

import Foundation

class RestClientImplementation: RestClient {

    let categoryUrl = "https://api.chucknorris.io/jokes/categories"
    let categoryImageUrl = "https://api.chucknorris.io/jokes/random?category=%@"
    let decoder = JSONDecoder()


    /// Devuelve un arreglo con categorias
    ///
    /// - Parameter completionHandler: Arreglo de CategoryModel
    func getCategories(completionHandler: @escaping ([CategoryModel]?) -> Void) {
        guard let url = URL(string: categoryUrl) else {
            print("error creating url")
            return
        }

        let task = URLSession.shared.dataTask(with: url) {(data, response, error) in
            if let data = data {
                do {
                    let categories = try self.decoder.decode([CategoryModel].self, from: data)
                    completionHandler(categories)
                } catch {
                    print(error)
                }
            } else {
                print("Error retrieving data")
            }
        }
        task.resume()
    }

    /// Ejecuta una consulta que devuelve un modelo CategoryImage donde estara nuestro chiste
    ///
    /// - Parameters:
    ///   - categoryName: Categoria a consultar
    ///   - completionHandler: modelo CategoryImage
    func getCategoryImages(categoryName: String, completionHandler: @escaping (CategoryImage?) -> Void) {
        guard let url = URL(string: String(format: categoryImageUrl, categoryName)) else {
            print("error creating url")
            return
        }

        let task = URLSession.shared.dataTask(with: url) {(data, response, error) in
            if let data = data {
                do {
                    let categoryImage = try self.decoder.decode(CategoryImage.self, from: data)
                    completionHandler(categoryImage)
                } catch {
                    print(error)
                }
            } else {
                print("Error retrieving data")
            }
        }
        task.resume()
    }

    /// Descargara la data de la imagen en la url prevista
    ///
    /// - Parameters:
    ///   - urlString: representacion de url en string
    ///   - completionHandler: Data de la imagen
    func downloadImage(urlString: String, completionHandler: @escaping (Data?) -> Void) {
        guard let url = URL(string: urlString) else {
            print("error creating url")
            return
        }

        let task = URLSession.shared.dataTask(with: url) {(data, response, error) in
            if let data = data {
                completionHandler(data)
            } else {
                print("Error retrieving data")
            }
        }
        task.resume()
    }
}
