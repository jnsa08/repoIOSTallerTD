//
//  DetailViewController.swift
//  RestSample
//
//  Created by Felipe Ruz on 08-03-18.
//  Copyright © 2018 Felipe Ruz. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    var category: CategoryModel!
    var restCient: RestClient!
    @IBOutlet weak var textView: UITextView!

    convenience init(category: CategoryModel) {
        self.init()
        self.category = category
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        restCient = RestClientImplementation()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        restCient.getCategoryImages(categoryName: category.name) {
            (categoryImage) in
            if let categoryImage = categoryImage {
                DispatchQueue.main.async {
                    self.textView.text = categoryImage.value
                }
            }
        }
    }
}
