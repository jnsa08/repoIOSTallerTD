//
//  RestClient.swift
//  RestSample
//
//  Created by Felipe Ruz on 07-03-18.
//  Copyright © 2018 Felipe Ruz. All rights reserved.
//

import Foundation


/// Interface para crear clientes rests
protocol RestClient {
    func getCategories(completionHandler: @escaping ([CategoryModel]?) -> Void)
    func getCategoryImages(categoryName: String, completionHandler: @escaping (CategoryImage?) -> Void)
    func downloadImage(urlString: String, completionHandler: @escaping (Data?) -> Void)
}
