//
//  ViewController.swift
//  UserDefaultsExample
//
//  Created by Felipe Ruz on 07-03-18.
//  Copyright © 2018 Felipe Ruz. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var saveKeyTextField: UITextField!
    @IBOutlet weak var saveValueTextField: UITextField!
    @IBOutlet weak var readKeyTextField: UITextField!
    @IBOutlet weak var saveButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        saveKeyTextField.delegate = self
        saveValueTextField.delegate = self
        readKeyTextField.delegate = self
        
        
        saveKeyTextField.addTarget(self, action: #selector(textFieldDidChangText), for:
            UIControlEvents.editingChanged)
        
        saveValueTextField.addTarget(self, action: #selector(textFieldDidChangText), for:
            UIControlEvents.editingChanged)
        
        
        saveButton.isEnabled = false
        saveButton.setTitle("Disabled", for: UIControlState.disabled)
        
    }

    @objc func textFieldDidChangText(){
        print(saveValueTextField.text!)
    }
    
    
    @IBAction func didPressSaveButton(_ sender: Any) {
    }
    
    @IBAction func didPressReadButton(_ sender: Any) {
    }
}

extension ViewController: UITextFieldDelegate{
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if saveKeyTextField.text === textField{
            print("Termine e escribir " + textField.text!)
        }
        
    }
    
}
