//
//  DetailViewController.swift
//  CoreDataExample
//
//  Created by Felipe Ruz on 07-03-18.
//  Copyright © 2018 Felipe Ruz. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var ageLabel: UILabel!
    @IBOutlet weak var sexLabel: UILabel!

    private(set) var user: User?

    convenience init(user: User) {
        self.init()
        self.user = user
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Detalle"
        prepareData()
    }

    private func prepareData() {
        guard let user = user else { return }
        nameLabel.text = user.nombre
        ageLabel.text = user.edad
        sexLabel.text = user.sexo
    }
}
