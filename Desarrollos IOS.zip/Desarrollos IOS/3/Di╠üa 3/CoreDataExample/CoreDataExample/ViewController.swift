//
//  ViewController.swift
//  CoreDataExample
//
//  Created by Felipe Ruz on 06-03-18.
//  Copyright © 2018 Felipe Ruz. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    var users: [User] = []
    var managedContext: NSManagedObjectContext!

    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Usuarios"
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        tableView.dataSource = self
        tableView.delegate = self
        loadContext()
        loadUsers()
    }

    private func loadContext() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        managedContext = appDelegate.persistentContainer.viewContext
    }

    @IBAction func addUser(_ sender: UIBarButtonItem) {
        let alert = UIAlertController(title: "Nuevo Usuario", message: "Añade un nuevo Usuario", preferredStyle: .alert)

        let saveAction = UIAlertAction(title: "Guardar", style: .default) { [unowned self] action in
            guard
                let nameField = alert.textFields?[0].text,
                let ageField = alert.textFields?[1].text,
                let sexField = alert.textFields?[2].text
                else { return }

            self.saveNewUser(name: nameField, age: ageField, sex: sexField)
            self.tableView.reloadData()
        }

        let cancelAction = UIAlertAction(title: "Cancel",
                                         style: .default)

        alert.addTextField()
        alert.addTextField()
        alert.addTextField()

        alert.addAction(saveAction)
        alert.addAction(cancelAction)

        present(alert, animated: true)
    }

    func saveNewUser(name: String, age: String, sex: String) {

        let user = User(context: managedContext)

        user.nombre = name
        user.edad = age
        user.sexo = sex

        do {
            try managedContext.save()
            users.append(user)
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
    }

    func loadUsers() {

        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "User")

        do {
            users = try managedContext.fetch(fetchRequest) as! [User]
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }

    func deleteUser(user: User) {
        managedContext.delete(user)
        users = []
        loadUsers()
        tableView.reloadData()
    }
}

extension ViewController: UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return users.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text = users[indexPath.row].nombre
        return cell
    }
}

extension ViewController: UITableViewDelegate {

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let user = users[indexPath.row]
        let detailViewController = DetailViewController(user: user)
        self.navigationController?.pushViewController(detailViewController, animated: true)
    }

    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }

    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == UITableViewCellEditingStyle.delete) {
            let user = users[indexPath.row]
            deleteUser(user: user)
        }
    }
}

