//
//  UserDefaultService.swift
//  UserDefaultsExample
//
//  Created by Felipe Ruz on 07-03-18.
//  Copyright © 2018 Felipe Ruz. All rights reserved.
//

import Foundation

struct UserDefaultService {

    let userDefaults: UserDefaults

    init(userDefaults: UserDefaults = UserDefaults()) {
        self.userDefaults = userDefaults
    }

    func saveKey(_ key: String, value: Any) {
        userDefaults.set(value, forKey: key)
    }

    func removeKey(_ key: String) {
        userDefaults.removeObject(forKey: key)
    }

    func valueFor(key: String) -> Any? {
        return userDefaults.value(forKey: key)
    }
}
