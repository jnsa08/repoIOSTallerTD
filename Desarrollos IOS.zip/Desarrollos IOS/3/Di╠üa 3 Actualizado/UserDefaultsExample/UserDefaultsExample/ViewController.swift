//
//  ViewController.swift
//  UserDefaultsExample
//
//  Created by Felipe Ruz on 07-03-18.
//  Copyright © 2018 Felipe Ruz. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var readKeyTextField: UITextField!
    @IBOutlet weak var saveKeyTextField: UITextField!
    @IBOutlet weak var saveValueTextField: UITextField!
    @IBOutlet weak var saveButton: UIButton!
    var storage: UserDefaultService!

    override func viewDidLoad() {
        super.viewDidLoad()
        storage = UserDefaultService()
        saveButton.setTitle("Disabled", for: UIControlState.disabled)
        updateButton(enabled: false)

        saveKeyTextField.delegate = self
        saveValueTextField.delegate = self
        readKeyTextField.delegate = self

        saveKeyTextField.addTarget(self, action: #selector(textFieldDidChangeText), for: UIControlEvents.editingChanged)
        saveValueTextField.addTarget(self, action: #selector(textFieldDidChangeText), for: UIControlEvents.editingChanged)
    }

    func updateButton(enabled: Bool) {
        saveButton.isEnabled = enabled ? true : false
        saveButton.backgroundColor = enabled ? UIColor.blue : UIColor.red
    }

    @IBAction func didPressSaveButton(_ sender: Any) {
        guard
            let key = saveKeyTextField.text,
            let value = saveValueTextField.text
            else {
                return
        }
        storage.saveKey(key, value: value)
    }

    @IBAction func didPressReadButton(_ sender: Any) {
        guard let key = readKeyTextField.text else { return }
        guard let value = storage.valueFor(key: key) as? String else { return }
        print(value)
    }

    @objc func textFieldDidChangeText() {
        if (saveValueTextField.text?.isEmpty)! || (saveKeyTextField.text?.isEmpty)! {
            updateButton(enabled: false)
        } else {
            updateButton(enabled: true)
        }
    }
}

extension ViewController: UITextFieldDelegate {
    func textFieldDidEndEditing(_ textField: UITextField) {
        if saveValueTextField === textField {
            print("Termime de escribir" + textField.text!)
        }
    }
}
