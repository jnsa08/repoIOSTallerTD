//
//  KeychainService.swift
//  KeychainExample
//
//  Created by Felipe Ruz on 07-03-18.
//  Copyright © 2018 Felipe Ruz. All rights reserved.
//

import Foundation

struct KeychainService {
    let service: String

    init(service: String) {
        self.service = service
    }

    func read(_ key: String) -> String {
        let queryResult = request(key: key).queryResult

        guard let existingItem = queryResult as? [String: AnyObject],
            let itemData = existingItem[kSecValueData as String] as? Data,
            let item = String(data: itemData, encoding: String.Encoding.utf8)
            else {
                fatalError("Could not properly read item for key: \(key)")
        }

        return item
    }

    func contains(_ key: String) -> Bool {
        let status = request(key: key).status

        if status != errSecItemNotFound {
            return true
        } else {
            return false
        }
    }

    private func request(key: String) -> (queryResult: AnyObject?, status: OSStatus) {
        var query = KeychainService.keychainQuery(withService: service, for: key)
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        query[kSecReturnAttributes as String] = kCFBooleanTrue
        query[kSecReturnData as String] = kCFBooleanTrue

        // Try to fetch the existing keychain item that matches the query.
        var queryResult: AnyObject?
        let status = withUnsafeMutablePointer(to: &queryResult) {
            SecItemCopyMatching(query as CFDictionary, UnsafeMutablePointer($0))
        }
        return (queryResult, status)
    }

    func save(key: String, value: String) {
        guard let encondedValue = value.data(using: String.Encoding.utf8) else {
            fatalError("Could not enconde value: \(value) in UTF8")
        }

        if contains(key) {
            var attributesToUpdate = [String: AnyObject]()
            attributesToUpdate[kSecValueData as String] = encondedValue as AnyObject?
            let query = KeychainService.keychainQuery(withService: service, for: key)
            let status = SecItemUpdate(query as CFDictionary, attributesToUpdate as CFDictionary)

            if status != noErr { fatalError("Could not update item: \(value) for key: \(key)") }
        } else {
            var newItem = KeychainService.keychainQuery(withService: service, for: key)
            newItem[kSecValueData as String] = encondedValue as AnyObject?
            let status = SecItemAdd(newItem as CFDictionary, nil)
            if status != noErr { fatalError("Could not save item: \(value) for key: \(key)") }
        }
    }

    func delete(_ key: String) {
        let query = KeychainService.keychainQuery(withService: service, for: key)
        let status = SecItemDelete(query as CFDictionary)

        if status != noErr && status != errSecItemNotFound {
            fatalError("Could not delete item for key \(key)")
        }
    }

    private static func keychainQuery(withService service: String, for key: String) -> [String: AnyObject] {
        var query = [String: AnyObject]()
        query[kSecClass as String] = kSecClassGenericPassword
        query[kSecAttrService as String] = service as AnyObject?
        query[kSecAttrAccount as String] = key as AnyObject?

        return query
    }
}
