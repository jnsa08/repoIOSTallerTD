//
//  ViewController.swift
//  KeychainExample
//
//  Created by Felipe Ruz on 07-03-18.
//  Copyright © 2018 Felipe Ruz. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var userField: UITextField!
    @IBOutlet weak var passwordField: UITextField!

    var keyChainService: KeychainService!
    var touchID: TouchIDHandler!
    var success: Bool = false {
        didSet {
            updatePasswordField()
        }
    }

    let VCUpdateTextFieldNotification = Notification.Name("VCUpdateTextFieldNotification")

    override func viewDidLoad() {
        super.viewDidLoad()
        keyChainService = KeychainService(service: "pepito")
        touchID = TouchIDHandler(message: "Ingresa la Huella")
    }

    @IBAction func didTapEnterButton(_ sender: Any) {
        if !(userField.text?.isEmpty)! || !(passwordField.text?.isEmpty)! {
            keyChainService.save(key: userField.text!, value: passwordField.text!)
        } else {
            print("user name or password empty")
        }
    }

    @IBAction func didTapFillButton(_ sender: Any) {
        if !(userField.text?.isEmpty)! {
            let password = keyChainService.read(userField.text!)
            passwordField.text = password
        }
    }

    @IBAction func didTapFingerPrintButton(_ sender: Any) {
        touchID.authenticateUser { (sucess, error) in
            if sucess {
                self.success = true
            } else {
                print(error.debugDescription)
            }
        }
    }

    func updatePasswordField() {
        DispatchQueue.main.async {
            let password = self.keyChainService.read(self.userField.text!)
            self.passwordField.text = password
        }
    }
}

