//
//  File.swift
//  KeychainExample
//
//  Created by Felipe Ruz on 07-03-18.
//  Copyright © 2018 Felipe Ruz. All rights reserved.
//

import Foundation
import LocalAuthentication

class TouchIDHandler {

    var context = LAContext()
    private let defaultPolicy: LAPolicy = .deviceOwnerAuthenticationWithBiometrics

    let message: String

    init(message: String) {
        self.message = message
    }

    enum TouchIDError {
        case notEnrolled
        case notAvailable
        case cancelled
        case fallback
        case failed
        case locked
        case unknown
    }

    func touchIDAvailable() -> (available: Bool, reason: TouchIDError?) {
        var error: NSError?
        context.canEvaluatePolicy(defaultPolicy, error: &error)

        if let error = error {
            let reason = TouchIDHandler.touchIDError(error: error)
            return (false, reason)
        } else {
            return (true, nil)
        }
    }

    func authenticateUser(completion: @escaping (_ success: Bool, _ reason: TouchIDError?) -> Void) {
        if touchIDAvailable().available {
            context.evaluatePolicy(defaultPolicy, localizedReason: message, reply: { success, error in
                if let error = error {
                    let reason = TouchIDHandler.touchIDError(error: error)
                    completion(success, reason)
                } else {
                    completion(success, nil)
                }
            })
        }
    }

    class func touchIDError(error: Error?) -> TouchIDError {
        switch error {
        case LAError.authenticationFailed?:
            return .failed
        case LAError.userCancel?:
            return .cancelled
        case LAError.userFallback?:
            return .fallback
        case LAError.touchIDLockout?:
            return .locked
        case LAError.touchIDNotEnrolled?:
            return .notEnrolled
        case LAError.touchIDNotAvailable?:
            return .notAvailable
        default:
            return .unknown
        }
    }
}

