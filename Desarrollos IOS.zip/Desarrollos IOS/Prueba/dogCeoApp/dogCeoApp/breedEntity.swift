//
//  BreedEntity.swift
//  dogCeoApp
//
//  Created by capacitacion3 on 09-03-18.
//  Copyright © 2018 capacitacion3. All rights reserved.
//

import Foundation

struct BreedEntity: Codable {
    let name: String
    

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        self.name = try container.decode(String.self)
    }
    
}

