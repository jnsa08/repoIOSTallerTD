//
//  DetailViewController.swift
//  dogCeoApp
//
//  Created by capacitacion3 on 09-03-18.
//  Copyright © 2018 capacitacion3. All rights reserved.
//

import UIKit
import SDWebImage

class DetailViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    var restClient: RestClient!
    var imagesUrl: [BreedEntity] = []
    var breed: BreedEntity!
    
    convenience init(breed: BreedEntity) {
        self.init()
        self.breed = breed
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Images"
        restClient = RestClientImplementation()
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        restClient.getBreedImages(breedName: breed.name) { (imagesUrl) in
            if let imagesUrl = imagesUrl {
                self.imagesUrl = imagesUrl
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            } else {
                print("Error")
            }
        }
        tableView.dataSource = self
    }
    

}

extension DetailViewController: UITableViewDataSource {
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return imagesUrl.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell: UITableViewCell
        
        if indexPath.row % 2 == 0 {
            cell = tableView.dequeueReusableCell(withIdentifier: "Cell")!
        } else {
            cell =  UITableViewCell.init(style: UITableViewCellStyle.subtitle, reuseIdentifier: "Cell")
        }
        cell.textLabel?.text = imagesUrl[indexPath.row].name
        cell.textLabel?.numberOfLines = 3;
        cell.imageView?.contentMode = UIViewContentMode.scaleAspectFit
        cell.imageView?.sd_setImage(with: URL(string : imagesUrl[indexPath.row].name), placeholderImage:  #imageLiteral(resourceName: "vacio"))
        return cell
}
}
