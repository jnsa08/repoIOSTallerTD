//
//  ViewController.swift
//  dogCeoApp
//
//  Created by capacitacion3 on 09-03-18.
//  Copyright © 2018 capacitacion3. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    var restClient: RestClient!
    var breeds: [BreedEntity] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Breeds"
        restClient = RestClientImplementation()
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        tableView.delegate = self
        tableView.dataSource = self
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        restClient.getBreeds { (breeds) in
            if let breeds = breeds {
                self.breeds = breeds
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            } else {
                print("Error")
            }
        }
    }


}


extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let breed = breeds[indexPath.row]
        let vc = DetailViewController(breed : breed)
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension ViewController: UITableViewDataSource {
    
    /// Devuelve el numero de elementos en cada seccion de la tabla
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return breeds.count
    }
    
    /// Devuelve la celda que dibujara la tabla
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell: UITableViewCell
        
        if indexPath.row % 2 == 0 {
            cell = tableView.dequeueReusableCell(withIdentifier: "Cell")!
        } else {
            cell =  UITableViewCell.init(style: UITableViewCellStyle.subtitle, reuseIdentifier: "Cell")
        }
        cell.textLabel?.text = breeds[indexPath.row].name.capitalized
        return cell
}

}
