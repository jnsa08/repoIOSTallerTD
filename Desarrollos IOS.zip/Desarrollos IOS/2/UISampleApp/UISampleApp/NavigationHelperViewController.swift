//
//  NavigationHelperViewController.swift
//  UISampleApp
//
//  Created by Felipe Ruz on 06-03-18.
//  Copyright © 2018 Felipe Ruz. All rights reserved.
//

import UIKit

class NavigationHelperViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "NavigationHelper"
    }

    @IBAction func pushSecondViewController(_ sender: Any) {
        let vc = SecondViewController(nibName: "SecondViewController", bundle: Bundle.main)
        self.navigationController?.pushViewController(vc, animated: true)

    }

    @IBAction func goBack(_ sender: Any) {
        let storyBoard = UIStoryboard(name: "Main", bundle: Bundle.main)
        let vc = storyBoard.instantiateInitialViewController()
        UIApplication.shared.keyWindow?.rootViewController = vc
    }


}
