//
//  AnotherViewController.swift
//  UISampleApp
//
//  Created by Felipe Ruz on 06-03-18.
//  Copyright © 2018 Felipe Ruz. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var closeButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        if navigationController != nil {
            closeButton.isHidden = true
        }
    }

    @IBAction func didTapCloseButton(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}
