//
//  ViewController.swift
//  UISampleApp
//
//  Created by Felipe Ruz on 06-03-18.
//  Copyright © 2018 Felipe Ruz. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageLogo: UIImageView!
    var navContoller: UINavigationController!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func didTapPresentButton(_ sender: UIButton) {
        let vc = SecondViewController(nibName: "SecondViewController", bundle: Bundle.main)
        present(vc, animated: true, completion: nil)
    }

    @IBAction func didTapPushButton(_ sender: UIButton) {
        let vc = NavigationHelperViewController(nibName: "NavigationHelperViewController", bundle: Bundle.main)
        let navigationController = UINavigationController(rootViewController: vc)
        UIApplication.shared.keyWindow?.rootViewController = navigationController
    }
}

