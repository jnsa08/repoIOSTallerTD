//
//  RestClient.swift
//  RestSample
//
//  Created by Felipe Ruz on 07-03-18.
//  Copyright © 2018 Felipe Ruz. All rights reserved.
//

import Foundation

protocol RestClient {
    func getCategories(completionHandler: @escaping ([Category]?) -> Void)
    func getCategoryImages(category: String, completionHandler: @escaping (CategoryImage?) -> Void)
    func downloadImage(urlString: String, completionHandler: @escaping (Data?) -> Void)
}
