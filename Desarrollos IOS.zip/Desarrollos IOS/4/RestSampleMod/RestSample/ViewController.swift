//
//  ViewController.swift
//  RestSample
//
//  Created by Felipe Ruz on 07-03-18.
//  Copyright © 2018 Felipe Ruz. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    var restClient: RestClient!
    var categories: [Category] = []

    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Categories"
        restClient = RestClientImplementation()
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        tableView.delegate = self
        tableView.dataSource = self
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        restClient.getCategories { (categories) in
            if let categories = categories {
                self.categories = categories
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            } else {
                print("Error")
            }
        }
    }
}

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let category = categories[indexPath.row]
        let vc = DetailViewController(category: category.name)
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension ViewController: UITableViewDataSource {
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return categories.count
    }

    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell")
        cell?.textLabel?.text = categories[indexPath.row].name
        return cell!
    }
}

