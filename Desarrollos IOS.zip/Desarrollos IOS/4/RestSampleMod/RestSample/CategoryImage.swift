//
//  CategoryImage.swift
//  RestSample
//
//  Created by Felipe Ruz on 07-03-18.
//  Copyright © 2018 Felipe Ruz. All rights reserved.
//

import Foundation

struct CategoryImage: Codable {
    let icon: String
    let id: String
    let url: String
    let value: String

    private enum CodingKeys: String, CodingKey {
        case icon = "icon_url"
        case id
        case url
        case value
    }
}
