//
//  ViewController.swift
//  UiSampleApp
//
//  Created by capacitacion3 on 06-03-18.
//  Copyright © 2018 capacitacion3. All rights reserved.
//

import UIKit
import SkyFloatingLabelTextField

class ViewController: UIViewController {

    @IBOutlet weak var imageLogo: UIImageView!

    override func viewDidLoad() {
        
        super.viewDidLoad()
        
    }
    
    @IBAction func didTapActionButton(_ sender: Any) {
       let vc = SecondViewController()
        self.present(vc, animated: true) {
            DispatchQueue.main.asyncAfter(deadline:DispatchTime.now() + 10, execute: {
                
                vc.dismiss(animated: true, completion: nil)
                
            })
            
            
                
            }
        }
    }
    

